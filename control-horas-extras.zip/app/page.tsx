"use client"

import { useState, useEffect } from "react"
import { format, addDays, startOfWeek, parse, differenceInHours } from "date-fns"
import { es } from "date-fns/locale"
import { Calendar } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { cn } from "@/lib/utils"

// Lista de días festivos en Colombia 2024 (ejemplo)
const diasFestivos2024 = [
  "2024-01-01", // Año Nuevo
  "2024-01-08", // Día de los Reyes Magos
  "2024-03-25", // Día de San José
  "2024-03-28", // Jueves Santo
  "2024-03-29", // Viernes Santo
  "2024-05-01", // Día del Trabajo
  "2024-05-13", // Día de la Ascensión
  "2024-06-03", // Corpus Christi
  "2024-06-10", // Sagrado Corazón
  "2024-07-01", // San Pedro y San Pablo
  "2024-07-20", // Día de la Independencia
  "2024-08-07", // Batalla de Boyacá
  "2024-08-19", // Asunción de la Virgen
  "2024-10-14", // Día de la Raza
  "2024-11-04", // Todos los Santos
  "2024-11-11", // Independencia de Cartagena
  "2024-12-08", // Día de la Inmaculada Concepción
  "2024-12-25", // Navidad
]

// Cargos y salarios
const cargos = [
  { nombre: "BOMBERO", salario: 2000000 },
  { nombre: "TÉCNICO", salario: 2500000 },
  { nombre: "SUPERVISOR", salario: 3500000 },
  { nombre: "INGENIERO", salario: 4500000 },
]

// Interfaz para los datos de un día
interface DiaData {
  entrada: string
  salida: string
  total: string
  esFestivo: boolean
}

// Interfaz para los cálculos de horas
interface CalculoHoras {
  horasNormales: number
  horasNocturnasLV: number
  horasDiurnasFestivos: number
  horasNocturnasFestivos: number
  horasExtDiurnasLV: number
  horasExtNocturnasLV: number
  horasExtDiurnasFestivos: number
  horasExtNocturnasFestivos: number
}

export default function ControlHorasExtras() {
  const [fechaInicio, setFechaInicio] = useState<Date>(startOfWeek(new Date(), { weekStartsOn: 1 }))
  const [diasSemana, setDiasSemana] = useState<{ [key: string]: DiaData }>({})
  const [cargoSeleccionado, setCargoSeleccionado] = useState("BOMBERO")
  const [salarioMensual, setSalarioMensual] = useState(2000000)
  const [totalHorasMes, setTotalHorasMes] = useState(0)
  const [totalRecargos, setTotalRecargos] = useState(0)
  const [totalHorasExtras, setTotalHorasExtras] = useState(0)
  const [totalAPagar, setTotalAPagar] = useState(0)
  const [tiempoCompensatorio, setTiempoCompensatorio] = useState(0)
  const [calculoHoras, setCalculoHoras] = useState<CalculoHoras>({
    horasNormales: 0,
    horasNocturnasLV: 0,
    horasDiurnasFestivos: 0,
    horasNocturnasFestivos: 0,
    horasExtDiurnasLV: 0,
    horasExtNocturnasLV: 0,
    horasExtDiurnasFestivos: 0,
    horasExtNocturnasFestivos: 0,
  })

  // Inicializar los días de la semana
  useEffect(() => {
    const nuevoDiasSemana: { [key: string]: DiaData } = {}

    for (let i = 0; i < 7; i++) {
      const fecha = addDays(fechaInicio, i)
      const fechaStr = format(fecha, "yyyy-MM-dd")
      const esFestivo = esDiaFestivo(fecha)

      nuevoDiasSemana[fechaStr] = {
        entrada: "",
        salida: "",
        total: "",
        esFestivo: esFestivo || i === 6, // Domingo o festivo
      }
    }

    setDiasSemana(nuevoDiasSemana)
  }, [fechaInicio])

  // Verificar si una fecha es festivo
  const esDiaFestivo = (fecha: Date): boolean => {
    const fechaStr = format(fecha, "yyyy-MM-dd")
    const esDomingo = fecha.getDay() === 0
    return esDomingo || diasFestivos2024.includes(fechaStr)
  }

  // Manejar cambio de cargo
  const handleCambiarCargo = (valor: string) => {
    setCargoSeleccionado(valor)
    const cargo = cargos.find((c) => c.nombre === valor)
    if (cargo) {
      setSalarioMensual(cargo.salario)
    }
  }

  // Manejar cambio de entrada/salida
  const handleCambioHora = (fecha: string, tipo: "entrada" | "salida", valor: string) => {
    setDiasSemana((prev) => {
      const nuevoDiasSemana = { ...prev }
      nuevoDiasSemana[fecha] = {
        ...nuevoDiasSemana[fecha],
        [tipo]: valor,
      }

      // Calcular total de horas si ambos valores están presentes
      if (nuevoDiasSemana[fecha].entrada && nuevoDiasSemana[fecha].salida) {
        try {
          const horaEntrada = parse(nuevoDiasSemana[fecha].entrada, "HH:mm", new Date())
          const horaSalida = parse(nuevoDiasSemana[fecha].salida, "HH:mm", new Date())

          // Si la salida es antes que la entrada, asumimos que es del día siguiente
          let horas = differenceInHours(horaSalida, horaEntrada)
          if (horas < 0) {
            horas = horas + 24
          }

          nuevoDiasSemana[fecha].total = `${horas}:00`
        } catch (error) {
          nuevoDiasSemana[fecha].total = "Error"
        }
      } else {
        nuevoDiasSemana[fecha].total = ""
      }

      return nuevoDiasSemana
    })
  }

  // Calcular todas las horas y recargos
  const calcularHorasYRecargos = () => {
    let totalHoras = 0
    let horasNocturnasLV = 0
    let horasDiurnasFestivos = 0
    let horasNocturnasFestivos = 0
    let horasExtDiurnasLV = 0
    let horasExtNocturnasLV = 0
    let horasExtDiurnasFestivos = 0
    let horasExtNocturnasFestivos = 0

    // Procesar cada día con datos
    Object.entries(diasSemana).forEach(([fecha, dia]) => {
      if (!dia.entrada || !dia.salida || dia.total === "Error") return

      try {
        const fechaDate = parse(fecha, "yyyy-MM-dd", new Date())
        const esFestivo = dia.esFestivo
        const horaEntrada = parse(dia.entrada, "HH:mm", fechaDate)
        let horaSalida = parse(dia.salida, "HH:mm", fechaDate)

        // Si la salida es antes que la entrada, asumimos que es del día siguiente
        if (horaSalida < horaEntrada) {
          horaSalida = addDays(horaSalida, 1)
        }

        // Horas totales de este día
        const horasTotales = differenceInHours(horaSalida, horaEntrada)
        totalHoras += horasTotales

        // Dividir las horas en intervalos según los criterios
        let horaActual = new Date(horaEntrada)

        while (horaActual < horaSalida) {
          const horaFin = new Date(horaActual)
          horaFin.setHours(horaFin.getHours() + 1)

          const esNocturno = horaActual.getHours() >= 18 || horaActual.getHours() < 6

          // Determinar tipo de hora según criterios
          if (totalHoras <= 190) {
            // Recargos hasta 190 horas
            if (esFestivo) {
              if (esNocturno) {
                horasNocturnasFestivos += 1
              } else {
                horasDiurnasFestivos += 1
              }
            } else if (esNocturno) {
              horasNocturnasLV += 1
            }
          } else {
            // Horas extras después de 190 horas
            if (esFestivo) {
              if (esNocturno) {
                horasExtNocturnasFestivos += 1
              } else {
                horasExtDiurnasFestivos += 1
              }
            } else {
              if (esNocturno) {
                horasExtNocturnasLV += 1
              } else {
                horasExtDiurnasLV += 1
              }
            }
          }

          horaActual = horaFin
        }
      } catch (error) {
        console.error("Error al calcular horas:", error)
      }
    })

    // Actualizar estado con los cálculos
    setTotalHorasMes(totalHoras)
    setCalculoHoras({
      horasNormales: Math.min(totalHoras, 190) - horasNocturnasLV - horasDiurnasFestivos - horasNocturnasFestivos,
      horasNocturnasLV,
      horasDiurnasFestivos,
      horasNocturnasFestivos,
      horasExtDiurnasLV,
      horasExtNocturnasLV,
      horasExtDiurnasFestivos,
      horasExtNocturnasFestivos,
    })

    // Calcular valores monetarios
    const valorHora = salarioMensual / 190

    // Recargos
    const recargoNocturnoLV = valorHora * horasNocturnasLV * 0.35
    const recargoDiurnoFestivo = valorHora * horasDiurnasFestivos * 2.0
    const recargoNocturnoFestivo = valorHora * horasNocturnasFestivos * 2.35

    // Horas extras
    const extraDiurnaLV = valorHora * horasExtDiurnasLV * 1.25
    const extraNocturnaLV = valorHora * horasExtNocturnasLV * 1.75
    const extraDiurnaFestivo = valorHora * horasExtDiurnasFestivos * 2.25
    const extraNocturnaFestivo = valorHora * horasExtNocturnasFestivos * 2.75

    const totalRecargosCalculado = recargoNocturnoLV + recargoDiurnoFestivo + recargoNocturnoFestivo
    const totalExtrasCalculado = extraDiurnaLV + extraNocturnaLV + extraDiurnaFestivo + extraNocturnaFestivo

    // Verificar tope del 50% del salario
    const topeMaximo = salarioMensual * 0.5
    let pagoExtras = totalExtrasCalculado
    let horasCompensatorias = 0

    if (totalExtrasCalculado > topeMaximo) {
      pagoExtras = topeMaximo
      // Convertir el excedente a tiempo compensatorio (en horas)
      const excedente = totalExtrasCalculado - topeMaximo
      horasCompensatorias = Math.round(excedente / valorHora)
    }

    setTotalRecargos(totalRecargosCalculado)
    setTotalHorasExtras(pagoExtras)
    setTotalAPagar(totalRecargosCalculado + pagoExtras)
    setTiempoCompensatorio(horasCompensatorias)
  }

  // Navegar a la semana anterior
  const irSemanaAnterior = () => {
    setFechaInicio(addDays(fechaInicio, -7))
  }

  // Navegar a la semana siguiente
  const irSemanaSiguiente = () => {
    setFechaInicio(addDays(fechaInicio, 7))
  }

  // Limpiar todos los datos
  const limpiarTodo = () => {
    const nuevoDiasSemana = { ...diasSemana }
    Object.keys(nuevoDiasSemana).forEach((fecha) => {
      nuevoDiasSemana[fecha] = {
        ...nuevoDiasSemana[fecha],
        entrada: "",
        salida: "",
        total: "",
      }
    })
    setDiasSemana(nuevoDiasSemana)
  }

  // Generar reporte completo
  const generarReporte = () => {
    calcularHorasYRecargos()
    // Aquí se podría implementar la generación de un PDF o exportación de datos
    alert("Reporte generado correctamente")
  }

  return (
    <div className="container mx-auto py-6">
      <Card className="border-0 shadow-none">
        <CardHeader className="bg-red-700 text-white">
          <CardTitle className="text-center text-xl">CONTROL HORAS EXTRAS</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {/* Fecha de inicio */}
          <div className="bg-red-700 text-white p-4">
            <Label htmlFor="fecha-inicio" className="text-white">
              FECHA DE INICIO
            </Label>
            <div className="flex items-center gap-2">
              <Input
                id="fecha-inicio"
                type="date"
                value={format(fechaInicio, "yyyy-MM-dd")}
                onChange={(e) => setFechaInicio(new Date(e.target.value))}
                className="bg-white text-black"
              />
              <Calendar className="h-5 w-5" />
            </div>
          </div>

          {/* Tabla de días */}
          <div className="p-4">
            <div className="grid grid-cols-5 gap-4 font-bold mb-2 text-center">
              <div className="text-left">DÍA</div>
              <div>ENTRADA</div>
              <div>SALIDA</div>
              <div>TOTAL</div>
              <div>FESTIVOS</div>
            </div>

            {Object.entries(diasSemana).map(([fecha, dia]) => {
              const fechaDate = new Date(fecha)
              const nombreDia = format(fechaDate, "EEEE", { locale: es }).toUpperCase()
              const fechaFormateada = format(fechaDate, "dd/MM/yyyy")

              return (
                <div key={fecha} className="grid grid-cols-5 gap-4 mb-4 items-center">
                  <div>
                    <div className="font-bold">{nombreDia}</div>
                    <div className="text-gray-500 text-sm">{fechaFormateada}</div>
                  </div>
                  <div>
                    <Input
                      type="time"
                      value={dia.entrada}
                      onChange={(e) => handleCambioHora(fecha, "entrada", e.target.value)}
                    />
                  </div>
                  <div>
                    <Input
                      type="time"
                      value={dia.salida}
                      onChange={(e) => handleCambioHora(fecha, "salida", e.target.value)}
                    />
                  </div>
                  <div className="text-center">
                    <Input value={dia.total} readOnly className="text-center" />
                  </div>
                  <div className="flex justify-center">
                    <div
                      className={cn(
                        "w-8 h-8 rounded-full flex items-center justify-center",
                        dia.esFestivo ? "bg-red-700" : "bg-gray-200",
                      )}
                    >
                      {dia.esFestivo && <div className="w-3 h-3 bg-white rounded-full" />}
                    </div>
                  </div>
                </div>
              )
            })}
          </div>

          {/* Resumen y cálculos */}
          <div className="grid md:grid-cols-2 gap-6 p-4">
            <div>
              <h2 className="text-xl font-bold mb-4">TOTAL TRABAJO MENSUAL</h2>
              <div className="grid grid-cols-3 gap-4 mb-6">
                <div>
                  <Label>Tiempo total</Label>
                  <div className="text-2xl font-bold">{totalHorasMes}:00</div>
                </div>
                <div>
                  <Label>Recargos</Label>
                  <div className="text-2xl font-bold">${totalRecargos.toLocaleString()}</div>
                </div>
                <div>
                  <Label>Horas Extras</Label>
                  <div className="text-2xl font-bold">${totalHorasExtras.toLocaleString()}</div>
                </div>
              </div>

              <h2 className="text-xl font-bold mb-4">CALCULAR PRECIO HORAS EXTRAS</h2>
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div>
                  <Label htmlFor="cargo">Cargo</Label>
                  <Select value={cargoSeleccionado} onValueChange={handleCambiarCargo}>
                    <SelectTrigger id="cargo">
                      <SelectValue placeholder="Seleccionar cargo" />
                    </SelectTrigger>
                    <SelectContent>
                      {cargos.map((cargo) => (
                        <SelectItem key={cargo.nombre} value={cargo.nombre}>
                          {cargo.nombre}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Salario mensual</Label>
                  <div className="text-xl font-bold">$ {salarioMensual.toLocaleString()}</div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="font-bold mb-2">TOTAL A PAGAR</h3>
                  <div className="text-2xl font-bold">$ {totalAPagar.toLocaleString()}</div>
                </div>
                <div>
                  <h3 className="font-bold mb-2">TIEMPO COMPENSATORIO</h3>
                  <div className="text-2xl font-bold">{tiempoCompensatorio} Horas</div>
                </div>
              </div>
            </div>

            <div className="flex flex-col gap-4">
              <Button className="bg-red-700 hover:bg-red-800 text-white w-full py-6" onClick={calcularHorasYRecargos}>
                CALCULAR HORAS Y RECARGOS
              </Button>

              <Button className="bg-red-700 hover:bg-red-800 text-white w-full py-6" onClick={generarReporte}>
                GENERAR REPORTE COMPLETO
              </Button>

              <div className="grid grid-cols-3 gap-4 mt-auto">
                <Button variant="outline" className="border-red-700 text-red-700 hover:bg-red-50" onClick={limpiarTodo}>
                  LIMPIAR TODO
                </Button>
                <Button
                  variant="outline"
                  className="border-red-700 text-red-700 hover:bg-red-50"
                  onClick={irSemanaAnterior}
                >
                  SEMANA ANTERIOR
                </Button>
                <Button
                  variant="outline"
                  className="border-red-700 text-red-700 hover:bg-red-50"
                  onClick={irSemanaSiguiente}
                >
                  SEMANA SIGUIENTE
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
